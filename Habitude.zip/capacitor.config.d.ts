import type { CapacitorConfig } from "@capacitor/cli";
declare const config: CapacitorConfig;
export default config;
