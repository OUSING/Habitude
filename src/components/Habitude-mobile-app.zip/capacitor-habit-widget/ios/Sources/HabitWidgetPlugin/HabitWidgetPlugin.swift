import Foundation
import Capacitor
import WidgetKit

/**
 * Please read the Capacitor iOS Plugin Development Guide
 * here: https://capacitorjs.com/docs/plugins/ios
 *
 * This plugin only writes data — the actual widget UI lives in a separate
 * Widget Extension target that this plugin can't create by itself (Xcode
 * app extensions aren't something a Swift package/pod can add to a host
 * project). See WIDGET_SETUP.md at the repo root for the one-time manual
 * Xcode steps, and HabitudeWidget.swift in this plugin's `widget-extension/`
 * folder for the extension's source to copy in.
 *
 * Requires an App Group shared between the app and the widget extension —
 * set its id in capacitor.config.ts under `plugins.HabitWidget.appGroup`,
 * and enable the same App Group capability on both Xcode targets.
 */
@objc(HabitWidgetPlugin)
public class HabitWidgetPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "HabitWidgetPlugin"
    public let jsName = "HabitWidget"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "isAvailable", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateWidgetData", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateTasksWidget", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateStepWidget", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "updateDailyProgressWidget", returnType: CAPPluginReturnPromise)
    ]

    private static let dataKey = "todayHabitsJson"
    private static let tasksDataKey = "todayTasksJson"
    private static let stepDataKey = "stepWidgetJson"
    private static let progressDataKey = "dailyProgressJson"

    private var appGroupId: String {
        getConfig().getString("appGroup") ?? "group.com.example.habittracker"
    }

    @objc func isAvailable(_ call: CAPPluginCall) {
        let available = UserDefaults(suiteName: appGroupId) != nil
        call.resolve(["available": available])
    }

    @objc func updateWidgetData(_ call: CAPPluginCall) {
        let date = call.getString("date") ?? ""
        let habits = call.getArray("habits", JSObject.self) ?? []

        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            call.reject("Could not access the shared App Group container '\(appGroupId)'. See WIDGET_SETUP.md.")
            return
        }

        let payload: [String: Any] = ["date": date, "habits": habits]
        if let data = try? JSONSerialization.data(withJSONObject: payload) {
            defaults.set(data, forKey: Self.dataKey)
            WidgetCenter.shared.reloadAllTimelines()
        }
        call.resolve()
    }

    @objc func updateTasksWidget(_ call: CAPPluginCall) {
        let date = call.getString("date") ?? ""
        let tasks = call.getArray("tasks", JSObject.self) ?? []

        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            call.reject("Could not access the shared App Group container")
            return
        }

        let payload: [String: Any] = ["date": date, "tasks": tasks]
        if let data = try? JSONSerialization.data(withJSONObject: payload) {
            defaults.set(data, forKey: Self.tasksDataKey)
            WidgetCenter.shared.reloadAllTimelines()
        }
        call.resolve()
    }

    @objc func updateStepWidget(_ call: CAPPluginCall) {
        let steps = call.getInt("steps") ?? 0
        let goal = call.getInt("goal") ?? 8000

        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            call.reject("Could not access the shared App Group container")
            return
        }

        let payload: [String: Any] = ["steps": steps, "goal": goal]
        if let data = try? JSONSerialization.data(withJSONObject: payload) {
            defaults.set(data, forKey: Self.stepDataKey)
            WidgetCenter.shared.reloadAllTimelines()
        }
        call.resolve()
    }

    @objc func updateDailyProgressWidget(_ call: CAPPluginCall) {
        let done = call.getInt("done") ?? 0
        let total = call.getInt("total") ?? 0

        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            call.reject("Could not access the shared App Group container")
            return
        }

        let payload: [String: Any] = ["done": done, "total": total]
        if let data = try? JSONSerialization.data(withJSONObject: payload) {
            defaults.set(data, forKey: Self.progressDataKey)
            WidgetCenter.shared.reloadAllTimelines()
        }
        call.resolve()
    }
}
