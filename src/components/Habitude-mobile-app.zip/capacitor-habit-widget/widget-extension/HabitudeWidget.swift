import WidgetKit
import SwiftUI
import Charts

private let appGroupId = "group.com.example.habittracker"

// MARK: - Habit Widget
private let dataKey = "todayHabitsJson"
private let maxRows = 6

struct WidgetHabit: Decodable, Identifiable {
    let id: Int
    let name: String
    let color: String
    let completed: Bool
}

struct HabitChecklistPayload: Decodable {
    let date: String
    let habits: [WidgetHabit]
}

func loadPayload() -> HabitChecklistPayload? {
    guard let defaults = UserDefaults(suiteName: appGroupId), let data = defaults.data(forKey: dataKey) else { return nil }
    return try? JSONDecoder().decode(HabitChecklistPayload.self, from: data)
}

struct HabitEntry: TimelineEntry {
    let date: Date
    let payload: HabitChecklistPayload?
}

struct HabitTimelineProvider: TimelineProvider {
    func placeholder(in context: Context) -> HabitEntry { HabitEntry(date: Date(), payload: nil) }
    func getSnapshot(in context: Context, completion: @escaping (HabitEntry) -> Void) { completion(HabitEntry(date: Date(), payload: loadPayload())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<HabitEntry>) -> Void) {
        let entry = HabitEntry(date: Date(), payload: loadPayload())
        let nextRefresh = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }
}

private func colorFrom(_ hex: String) -> Color {
    var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
    guard s.count == 6, let value = UInt64(s, radix: 16) else { return Color(red: 0.92, green: 1.0, blue: 0.34) }
    let r = Double((value >> 16) & 0xFF) / 255
    let g = Double((value >> 8) & 0xFF) / 255
    let b = Double(value & 0xFF) / 255
    return Color(red: r, green: g, blue: b)
}

struct HabitudeWidgetView: View {
    let entry: HabitEntry
    var body: some View {
        let habits = entry.payload?.habits ?? []
        let visible = Array(habits.prefix(maxRows))
        let done = habits.filter { $0.completed }.count

        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Today's Habits")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color(red: 0.97, green: 0.97, blue: 0.95))
                Spacer()
                if !habits.isEmpty {
                    Text("\(done)/\(habits.count)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(Color(red: 0.92, green: 1.0, blue: 0.34))
                }
            }

            if entry.payload == nil {
                Text("Open Habitude to load today's habits").font(.system(size: 12)).foregroundColor(.gray)
            } else if habits.isEmpty {
                Text("No habits scheduled today").font(.system(size: 12)).foregroundColor(.gray)
            } else {
                ForEach(visible) { habit in
                    HStack(spacing: 8) {
                        Image(systemName: habit.completed ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 13))
                            .foregroundColor(colorFrom(habit.color))
                        Text(habit.name)
                            .font(.system(size: 12.5))
                            .foregroundColor(habit.completed ? .gray : Color(red: 0.97, green: 0.97, blue: 0.95))
                            .strikethrough(habit.completed)
                            .lineLimit(1)
                    }
                }
                if habits.count > maxRows {
                    Text("+\(habits.count - maxRows) more").font(.system(size: 11)).foregroundColor(.gray)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .widgetURL(URL(string: "habitude://open"))
    }
}

struct HabitudeWidget: Widget {
    let kind = "HabitudeWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: HabitTimelineProvider()) { entry in HabitudeWidgetView(entry: entry) }
        .configurationDisplayName("Today's Habits")
        .description("Shows today's habit checklist.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

// MARK: - Tasks Widget
private let tasksDataKey = "todayTasksJson"

struct WidgetTask: Decodable, Identifiable {
    let id: Int
    let text: String
    let completed: Bool
}

struct TasksChecklistPayload: Decodable {
    let date: String
    let tasks: [WidgetTask]
}

func loadTasksPayload() -> TasksChecklistPayload? {
    guard let defaults = UserDefaults(suiteName: appGroupId), let data = defaults.data(forKey: tasksDataKey) else { return nil }
    return try? JSONDecoder().decode(TasksChecklistPayload.self, from: data)
}

struct TasksEntry: TimelineEntry {
    let date: Date
    let payload: TasksChecklistPayload?
}

struct TasksTimelineProvider: TimelineProvider {
    func placeholder(in context: Context) -> TasksEntry { TasksEntry(date: Date(), payload: nil) }
    func getSnapshot(in context: Context, completion: @escaping (TasksEntry) -> Void) { completion(TasksEntry(date: Date(), payload: loadTasksPayload())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<TasksEntry>) -> Void) {
        let entry = TasksEntry(date: Date(), payload: loadTasksPayload())
        let nextRefresh = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }
}

struct TasksWidgetView: View {
    let entry: TasksEntry
    var body: some View {
        let tasks = entry.payload?.tasks ?? []
        let visible = Array(tasks.prefix(maxRows))
        let done = tasks.filter { $0.completed }.count

        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Today's Tasks")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color(red: 0.97, green: 0.97, blue: 0.95))
                Spacer()
                if !tasks.isEmpty {
                    Text("\(done)/\(tasks.count)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(Color(red: 0.92, green: 1.0, blue: 0.34))
                }
            }

            if entry.payload == nil {
                Text("Open Habitude to load today's tasks").font(.system(size: 12)).foregroundColor(.gray)
            } else if tasks.isEmpty {
                Text("No tasks scheduled today").font(.system(size: 12)).foregroundColor(.gray)
            } else {
                ForEach(visible) { task in
                    HStack(spacing: 8) {
                        Image(systemName: task.completed ? "checkmark.square.fill" : "square")
                            .font(.system(size: 13))
                            .foregroundColor(Color(red: 0.92, green: 1.0, blue: 0.34))
                        Text(task.text)
                            .font(.system(size: 12.5))
                            .foregroundColor(task.completed ? .gray : Color(red: 0.97, green: 0.97, blue: 0.95))
                            .strikethrough(task.completed)
                            .lineLimit(1)
                    }
                }
                if tasks.count > maxRows {
                    Text("+\(tasks.count - maxRows) more").font(.system(size: 11)).foregroundColor(.gray)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .widgetURL(URL(string: "habitude://tasks"))
    }
}

struct TasksWidget: Widget {
    let kind = "TasksWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TasksTimelineProvider()) { entry in TasksWidgetView(entry: entry) }
        .configurationDisplayName("Today's Tasks")
        .description("Shows today's tasks checklist.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

// MARK: - Step Tracker Widget
private let stepDataKey = "stepWidgetJson"

struct StepPayload: Decodable {
    let steps: Int
    let goal: Int
}

func loadStepPayload() -> StepPayload? {
    guard let defaults = UserDefaults(suiteName: appGroupId), let data = defaults.data(forKey: stepDataKey) else { return nil }
    return try? JSONDecoder().decode(StepPayload.self, from: data)
}

struct StepEntry: TimelineEntry {
    let date: Date
    let payload: StepPayload?
}

struct StepTimelineProvider: TimelineProvider {
    func placeholder(in context: Context) -> StepEntry { StepEntry(date: Date(), payload: nil) }
    func getSnapshot(in context: Context, completion: @escaping (StepEntry) -> Void) { completion(StepEntry(date: Date(), payload: loadStepPayload())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<StepEntry>) -> Void) {
        let entry = StepEntry(date: Date(), payload: loadStepPayload())
        let nextRefresh = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }
}

struct StepWidgetView: View {
    let entry: StepEntry
    var body: some View {
        let steps = entry.payload?.steps ?? 0
        let goal = entry.payload?.goal ?? 8000
        let progress = min(Double(steps) / Double(goal == 0 ? 1 : goal), 1.0)

        VStack {
            Text("Step Tracker")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(Color(red: 0.97, green: 0.97, blue: 0.95))
            
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.3), lineWidth: 10)
                
                Circle()
                    .trim(from: 0, to: CGFloat(progress))
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                
                VStack {
                    Text("\(steps)")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(Color(red: 0.97, green: 0.97, blue: 0.95))
                    Text("/\(goal)")
                        .font(.system(size: 10))
                        .foregroundColor(.gray)
                }
            }
            .padding(10)
        }
        .padding(14)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
        .widgetURL(URL(string: "habitude://steps"))
    }
}

struct StepWidget: Widget {
    let kind = "StepWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: StepTimelineProvider()) { entry in StepWidgetView(entry: entry) }
        .configurationDisplayName("Step Tracker")
        .description("Shows your daily step progress.")
        .supportedFamilies([.systemSmall])
    }
}

// MARK: - Daily Progress Chart Widget
private let progressDataKey = "dailyProgressJson"

struct DailyProgressPayload: Decodable {
    let done: Int
    let total: Int
}

func loadProgressPayload() -> DailyProgressPayload? {
    guard let defaults = UserDefaults(suiteName: appGroupId), let data = defaults.data(forKey: progressDataKey) else { return nil }
    return try? JSONDecoder().decode(DailyProgressPayload.self, from: data)
}

struct ProgressEntry: TimelineEntry {
    let date: Date
    let payload: DailyProgressPayload?
}

struct ProgressTimelineProvider: TimelineProvider {
    func placeholder(in context: Context) -> ProgressEntry { ProgressEntry(date: Date(), payload: nil) }
    func getSnapshot(in context: Context, completion: @escaping (ProgressEntry) -> Void) { completion(ProgressEntry(date: Date(), payload: loadProgressPayload())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<ProgressEntry>) -> Void) {
        let entry = ProgressEntry(date: Date(), payload: loadProgressPayload())
        let nextRefresh = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }
}

struct ProgressWidgetView: View {
    let entry: ProgressEntry
    var body: some View {
        let done = entry.payload?.done ?? 0
        let total = entry.payload?.total ?? 0
        let percent = total > 0 ? Int((Double(done) / Double(total)) * 100) : 0

        VStack(alignment: .leading, spacing: 6) {
            Text("TODAY")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.gray)
            
            Text("\(done) / \(total)")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(Color(red: 0.97, green: 0.97, blue: 0.95))
            
            Text(total == 0 ? "No habits scheduled today" : (done >= total ? "All habits complete" : "\(percent)% complete"))
                .font(.system(size: 11))
                .foregroundColor(.gray)
            
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color(red: 0.16, green: 0.16, blue: 0.16))
                        .frame(height: 8)
                    
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color(red: 0.92, green: 1.0, blue: 0.34))
                        .frame(width: max(0, min(geometry.size.width * CGFloat(total == 0 ? 0 : Double(done) / Double(total)), geometry.size.width)), height: 8)
                }
            }
            .frame(height: 8)
            .padding(.top, 6)
        }
        .padding(16)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(Color(red: 0.08, green: 0.08, blue: 0.08))
    }
}

struct ProgressWidget: Widget {
    let kind = "ProgressWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ProgressTimelineProvider()) { entry in ProgressWidgetView(entry: entry) }
        .configurationDisplayName("Daily Progress Chart")
        .description("Shows your overall progress for the day.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}


// MARK: - Widget Bundle
@main
struct HabitudeWidgetBundle: WidgetBundle {
    var body: some Widget {
        HabitudeWidget()
        TasksWidget()
        StepWidget()
        ProgressWidget()
    }
}
