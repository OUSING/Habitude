import { WebPlugin } from '@capacitor/core';

import type { HabitWidgetPlugin, UpdateWidgetDataOptions } from './definitions';

/** No home screen on a browser tab — every call is a harmless no-op so the
 *  rest of the app never has to branch on platform before calling this. */
export class HabitWidgetWeb extends WebPlugin implements HabitWidgetPlugin {
  async isAvailable(): Promise<{ available: boolean }> {
    return { available: false };
  }

  async updateWidgetData(_options: UpdateWidgetDataOptions): Promise<void> {
    return;
  }

  async updateTasksWidget(_options: any): Promise<void> {
    return;
  }

  async updateStepWidget(_options: any): Promise<void> {
    return;
  }

  async updateDailyProgressWidget(_options: any): Promise<void> {
    return;
  }

  async getAndClearPendingActions(): Promise<{ actions: { type: string; id: number; timestamp: number }[] }> {
    return { actions: [] };
  }
}
