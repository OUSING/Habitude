import { registerPlugin } from '@capacitor/core';

import type { HabitWidgetPlugin } from './definitions';

const HabitWidget = registerPlugin<HabitWidgetPlugin>('HabitWidget', {
  web: () => import('./web').then((m) => new m.HabitWidgetWeb())
});

export * from './definitions';
export { HabitWidget };
