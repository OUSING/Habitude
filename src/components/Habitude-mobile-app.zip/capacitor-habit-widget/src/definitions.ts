/** One row in the widget's checklist — a trimmed-down view of a Habit,
 *  with just what the native widget needs to render. */
export interface WidgetHabit {
  id: number;
  name: string;
  /** One of PALETTE's hex values, see src/utils/palette.ts in the app. */
  color: string;
  completed: boolean;
  /** Current scheduled-day streak. */
  streak?: number;
  /** Total completed check-ins. */
  checked?: number;
}

export interface UpdateWidgetDataOptions {
  /** "YYYY-MM-DD" local date the checklist belongs to — shown as the
   *  widget's date/subtitle so a stale (yesterday's) widget is obvious. */
  date: string;
  /** Today's scheduled habits, in display order. The native side decides
   *  how many rows fit and truncates (with a "+N more" row) — send the
   *  full list, not a pre-truncated one. */
  habits: WidgetHabit[];
}

export interface WidgetTask {
  id: number;
  text: string;
  completed: boolean;
}

export interface UpdateTasksWidgetOptions {
  date: string;
  tasks: WidgetTask[];
}

export interface UpdateStepWidgetOptions {
  steps: number;
  goal: number;
}

export interface UpdateDailyProgressWidgetOptions {
  done: number;
  total: number;
}

export interface HabitWidgetPlugin {
  /** Whether this platform can actually show a home screen widget (false
   *  on web, and on iOS until the widget extension described in
   *  WIDGET_SETUP.md has been added to the Xcode project). */
  isAvailable(): Promise<{ available: boolean }>;

  /** Pushes the current day's habit checklist to native storage and asks
   *  the OS to redraw any placed widget instances. Cheap — safe to call
   *  on every habit/log change. */
  updateWidgetData(options: UpdateWidgetDataOptions): Promise<void>;

  /** Pushes today's tasks to the Tasks widget. */
  updateTasksWidget(options: UpdateTasksWidgetOptions): Promise<void>;

  /** Pushes current steps and goal to the Step Tracker widget. */
  updateStepWidget(options: UpdateStepWidgetOptions): Promise<void>;

  /** Pushes simple completion stats to a daily progress / chart widget. */
  updateDailyProgressWidget(options: UpdateDailyProgressWidgetOptions): Promise<void>;

  /** Fetches any pending interactions (clicks) that the user performed on the native widget while the app was closed. */
  getAndClearPendingActions(): Promise<{ actions: { type: string; id: number; timestamp: number }[] }>;
}
