package com.adi.habitude.widget

import android.content.Context
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import org.json.JSONObject

@CapacitorPlugin(name = "HabitWidget")
class HabitWidgetPlugin : Plugin() {

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        val result = JSObject()
        result.put("available", true)
        call.resolve(result)
    }

    @PluginMethod
    fun updateWidgetData(call: PluginCall) {
        val date = call.getString("date") ?: ""
        val habits: JSArray = call.getArray("habits") ?: JSArray()

        val payload = JSONObject()
        payload.put("date", date)
        payload.put("habits", org.json.JSONArray(habits.toString()))

        val prefs = context.getSharedPreferences(HabitWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(HabitWidgetProvider.KEY_DATA, payload.toString()).apply()

        HabitWidgetProvider.refreshAll(context)
        call.resolve()
    }

    @PluginMethod
    fun updateTasksWidget(call: PluginCall) {
        val date = call.getString("date") ?: ""
        val tasks: JSArray = call.getArray("tasks") ?: JSArray()

        val payload = JSONObject()
        payload.put("date", date)
        payload.put("tasks", org.json.JSONArray(tasks.toString()))

        val prefs = context.getSharedPreferences(TasksWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(TasksWidgetProvider.KEY_DATA, payload.toString()).apply()

        TasksWidgetProvider.refreshAll(context)
        call.resolve()
    }

    @PluginMethod
    fun updateStepWidget(call: PluginCall) {
        val steps = call.getInt("steps") ?: 0
        val goal = call.getInt("goal") ?: 8000

        val prefs = context.getSharedPreferences(StepWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(StepWidgetProvider.KEY_STEPS, steps)
            .putInt(StepWidgetProvider.KEY_STEP_GOAL, goal)
            .apply()

        StepWidgetProvider.refreshAll(context)
        call.resolve()
    }

    @PluginMethod
    fun updateDailyProgressWidget(call: PluginCall) {
        val done = call.getInt("done") ?: 0
        val total = call.getInt("total") ?: 0

        val prefs = context.getSharedPreferences(DailyProgressWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(DailyProgressWidgetProvider.KEY_DONE, done)
            .putInt(DailyProgressWidgetProvider.KEY_TOTAL, total)
            .apply()

        DailyProgressWidgetProvider.refreshAll(context)
        call.resolve()
    }

    @PluginMethod
    fun getAndClearPendingActions(call: PluginCall) {
        val prefs = context.getSharedPreferences(HabitWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val queueStr = prefs.getString("pending_actions", "[]")
        
        val result = JSObject()
        try {
            val arr = org.json.JSONArray(queueStr)
            val jsArr = JSArray(arr)
            result.put("actions", jsArr)
            
            // clear the queue
            prefs.edit().remove("pending_actions").apply()
        } catch (e: Exception) {
            result.put("actions", JSArray())
        }
        
        call.resolve(result)
    }
}
