package com.adi.habitude.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

class TasksWidgetProvider : AppWidgetProvider() {

    companion object {
        const val PREFS_NAME = "TasksWidgetPrefs"
        const val KEY_DATA = "todayTasksJson"
        const val ACTION_TOGGLE = "com.adi.habitude.widget.ACTION_TOGGLE_TASK"
        private const val MAX_ROWS = 6

        private val ROW_IDS = intArrayOf(
            R.id.task_row_0, R.id.task_row_1, R.id.task_row_2,
            R.id.task_row_3, R.id.task_row_4, R.id.task_row_5
        )
        private val ICON_IDS = intArrayOf(
            R.id.check_icon_0, R.id.check_icon_1, R.id.check_icon_2,
            R.id.check_icon_3, R.id.check_icon_4, R.id.check_icon_5
        )
        private val NAME_IDS = intArrayOf(
            R.id.task_name_0, R.id.task_name_1, R.id.task_name_2,
            R.id.task_name_3, R.id.task_name_4, R.id.task_name_5
        )

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                android.content.ComponentName(context, TasksWidgetProvider::class.java)
            )
            if (ids.isNotEmpty()) {
                render(context, manager, ids)
            }
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs: SharedPreferences =
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_DATA, null)

            val views = RemoteViews(context.packageName, R.layout.widget_tasks_checklist)

            // Tapping anywhere on the widget opens the app.
            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launchIntent != null) {
                val pendingIntent = android.app.PendingIntent.getActivity(
                    context, 0, launchIntent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            }

            if (json == null) {
                views.setViewVisibility(R.id.empty_state, View.VISIBLE)
                views.setTextViewText(R.id.empty_state, "Open Habitude to load today's tasks")
                views.setTextViewText(R.id.widget_progress, "")
                for (i in 0 until MAX_ROWS) views.setViewVisibility(ROW_IDS[i], View.GONE)
                views.setViewVisibility(R.id.more_row, View.GONE)
                for (id in ids) manager.updateAppWidget(id, views)
                return
            }

            val tasks = JSONArray(JSONObject(json).optString("tasks", "[]"))
            val total = tasks.length()
            val done = (0 until total).count { tasks.getJSONObject(it).optBoolean("completed") }

            if (total == 0) {
                views.setViewVisibility(R.id.empty_state, View.VISIBLE)
                views.setTextViewText(R.id.empty_state, "No tasks scheduled today")
                views.setTextViewText(R.id.widget_progress, "")
            } else {
                views.setViewVisibility(R.id.empty_state, View.GONE)
                views.setTextViewText(R.id.widget_progress, "$done/$total")
            }

            val visibleCount = minOf(total, MAX_ROWS)
            for (i in 0 until MAX_ROWS) {
                if (i < visibleCount) {
                    val task = tasks.getJSONObject(i)
                    // The payload uses "text" not "name"
                    val name = task.optString("text", "")
                    val completed = task.optBoolean("completed", false)
                    val taskId = task.optInt("id", -1)
                    val color = try {
                        Color.parseColor(task.optString("color", "#EBFF57"))
                    } catch (e: IllegalArgumentException) {
                        Color.parseColor("#EBFF57")
                    }

                    views.setViewVisibility(ROW_IDS[i], View.VISIBLE)
                    views.setImageViewResource(
                        ICON_IDS[i],
                        if (completed) R.drawable.ic_task_check_filled else R.drawable.ic_task_check_outline
                    )
                    views.setInt(ICON_IDS[i], "setColorFilter", color)

                    val label: CharSequence = if (completed) {
                        SpannableString(name).apply {
                            setSpan(StrikethroughSpan(), 0, name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    } else {
                        name
                    }
                    views.setTextViewText(NAME_IDS[i], label)
                    views.setTextColor(
                        NAME_IDS[i],
                        if (completed) Color.parseColor("#A3A3A3") else Color.parseColor("#F7F7F2")
                    )

                    if (taskId != -1) {
                        val clickIntent = Intent(context, TasksWidgetProvider::class.java).apply {
                            action = ACTION_TOGGLE
                            putExtra("EXTRA_TASK_ID", taskId)
                        }
                        val clickPending = android.app.PendingIntent.getBroadcast(
                            context, taskId, clickIntent,
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(ROW_IDS[i], clickPending)
                    }
                } else {
                    views.setViewVisibility(ROW_IDS[i], View.GONE)
                }
            }

            if (total > MAX_ROWS) {
                views.setViewVisibility(R.id.more_row, View.VISIBLE)
                views.setTextViewText(R.id.more_row, "+${total - MAX_ROWS} more")
            } else {
                views.setViewVisibility(R.id.more_row, View.GONE)
            }

            for (id in ids) manager.updateAppWidget(id, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, manager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val taskId = intent.getIntExtra("EXTRA_TASK_ID", -1)
            if (taskId != -1) {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_DATA, null) ?: return
                
                try {
                    val root = JSONObject(jsonStr)
                    val tasks = root.optJSONArray("tasks") ?: JSONArray()
                    
                    for (i in 0 until tasks.length()) {
                        val task = tasks.getJSONObject(i)
                        if (task.optInt("id") == taskId) {
                            val current = task.optBoolean("completed", false)
                            task.put("completed", !current)
                            break
                        }
                    }
                    
                    root.put("tasks", tasks)
                    prefs.edit().putString(KEY_DATA, root.toString()).apply()

                    // Queue action (we write to HabitWidgetPrefs so there's one unified queue)
                    val globalPrefs = context.getSharedPreferences(HabitWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
                    val queueStr = globalPrefs.getString("pending_actions", "[]")
                    val queue = JSONArray(queueStr)
                    queue.put(JSONObject().apply {
                        put("type", "task")
                        put("id", taskId)
                        put("timestamp", System.currentTimeMillis())
                    })
                    globalPrefs.edit().putString("pending_actions", queue.toString()).apply()

                    refreshAll(context)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
