package com.adi.habitude.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.res.ColorStateList
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

class HabitWidgetProvider : AppWidgetProvider() {

    companion object {
        const val PREFS_NAME = "HabitWidgetPrefs"
        const val KEY_DATA = "todayHabitsJson"
        const val ACTION_TOGGLE = "com.adi.habitude.widget.ACTION_TOGGLE_HABIT"
        private const val MAX_ROWS = 3

        private val ROW_IDS = intArrayOf(
            R.id.habit_row_0, R.id.habit_row_1, R.id.habit_row_2,
            R.id.habit_row_3, R.id.habit_row_4, R.id.habit_row_5
        )
        private val ICON_IDS = intArrayOf(
            R.id.check_icon_0, R.id.check_icon_1, R.id.check_icon_2,
            R.id.check_icon_3, R.id.check_icon_4, R.id.check_icon_5
        )
        private val NAME_IDS = intArrayOf(
            R.id.habit_name_0, R.id.habit_name_1, R.id.habit_name_2,
            R.id.habit_name_3, R.id.habit_name_4, R.id.habit_name_5
        )
        private val STREAK_ICON_IDS = intArrayOf(
            R.id.streak_icon_0, R.id.streak_icon_1, R.id.streak_icon_2,
            R.id.streak_icon_3, R.id.streak_icon_4, R.id.streak_icon_5
        )
        private val STREAK_TEXT_IDS = intArrayOf(
            R.id.streak_text_0, R.id.streak_text_1, R.id.streak_text_2,
            R.id.streak_text_3, R.id.streak_text_4, R.id.streak_text_5
        )
        private val CHECKED_TEXT_IDS = intArrayOf(
            R.id.checked_text_0, R.id.checked_text_1, R.id.checked_text_2,
            R.id.checked_text_3, R.id.checked_text_4, R.id.checked_text_5
        )
        private val TOGGLE_IDS = intArrayOf(
            R.id.toggle_button_0, R.id.toggle_button_1, R.id.toggle_button_2,
            R.id.toggle_button_3, R.id.toggle_button_4, R.id.toggle_button_5
        )

        private fun withAlpha(color: Int, alpha: Int): Int =
            Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                android.content.ComponentName(context, HabitWidgetProvider::class.java)
            )
            if (ids.isNotEmpty()) {
                render(context, manager, ids)
            }
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs: SharedPreferences =
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(KEY_DATA, null)

            val views = RemoteViews(context.packageName, R.layout.widget_habit_checklist)

            // Header/Empty state clicks open the app
            val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launchIntent != null) {
                val pendingIntent = android.app.PendingIntent.getActivity(
                    context, 0, launchIntent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
            }

            if (json == null) {
                views.setViewVisibility(R.id.empty_state, View.VISIBLE)
                views.setTextViewText(R.id.empty_state, "Open Habitude to load today's habits")
                for (i in 0 until MAX_ROWS) views.setViewVisibility(ROW_IDS[i], View.GONE)
                views.setViewVisibility(R.id.more_row, View.GONE)
                for (id in ids) manager.updateAppWidget(id, views)
                return
            }

            val habits = JSONArray(JSONObject(json).optString("habits", "[]"))
            val total = habits.length()
            val done = (0 until total).count { habits.getJSONObject(it).optBoolean("completed") }

            if (total == 0) {
                views.setViewVisibility(R.id.empty_state, View.VISIBLE)
                views.setTextViewText(R.id.empty_state, "No habits scheduled today")
            } else {
                views.setViewVisibility(R.id.empty_state, View.GONE)
            }

            val visibleCount = minOf(total, MAX_ROWS)
            for (i in 0 until MAX_ROWS) {
                if (i < visibleCount) {
                    val habit = habits.getJSONObject(i)
                    val name = habit.optString("name", "")
                    val completed = habit.optBoolean("completed", false)
                    val habitId = habit.optInt("id", -1)
                    val color = try {
                        Color.parseColor(habit.optString("color", "#EBFF57"))
                    } catch (e: IllegalArgumentException) {
                        Color.parseColor("#EBFF57")
                    }

                    val streak = habit.optInt("streak", 0)
                    val checked = habit.optInt("checked", 0)

                    views.setViewVisibility(ROW_IDS[i], View.VISIBLE)
                    views.setColorStateList(
                        ROW_IDS[i],
                        "setBackgroundTintList",
                        ColorStateList.valueOf(withAlpha(color, 26))
                    )
                    views.setColorStateList(
                        ICON_IDS[i],
                        "setBackgroundTintList",
                        ColorStateList.valueOf(withAlpha(color, 28))
                    )
                    views.setImageViewResource(ICON_IDS[i], R.drawable.ic_habit_check_outline)
                    views.setInt(ICON_IDS[i], "setColorFilter", color)
                    views.setColorStateList(
                        TOGGLE_IDS[i],
                        "setBackgroundTintList",
                        ColorStateList.valueOf(color)
                    )
                    views.setTextColor(TOGGLE_IDS[i], Color.parseColor("#171717"))

                    if (streak > 0) {
                        views.setViewVisibility(STREAK_ICON_IDS[i], View.VISIBLE)
                        views.setViewVisibility(STREAK_TEXT_IDS[i], View.VISIBLE)
                        views.setImageViewResource(STREAK_ICON_IDS[i], R.drawable.ic_habit_flame)
                        views.setInt(STREAK_ICON_IDS[i], "setColorFilter", color)
                        views.setTextViewText(STREAK_TEXT_IDS[i], "$streak day streak")
                        views.setTextColor(STREAK_TEXT_IDS[i], color)
                    } else {
                        views.setViewVisibility(STREAK_ICON_IDS[i], View.GONE)
                        views.setViewVisibility(STREAK_TEXT_IDS[i], View.GONE)
                    }
                    if (checked > 0) {
                        views.setViewVisibility(CHECKED_TEXT_IDS[i], View.VISIBLE)
                        views.setTextViewText(CHECKED_TEXT_IDS[i], "✓ $checked checked")
                    } else {
                        views.setViewVisibility(CHECKED_TEXT_IDS[i], View.GONE)
                    }

                    val label: CharSequence = if (completed) {
                        SpannableString(name).apply {
                            setSpan(StrikethroughSpan(), 0, name.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    } else {
                        name
                    }
                    views.setTextViewText(NAME_IDS[i], label)
                    views.setTextColor(
                        NAME_IDS[i],
                        if (completed) Color.parseColor("#A3A3A3") else Color.parseColor("#F7F7F2")
                    )

                    // Clicking either the row or the round check button toggles the habit.
                    if (habitId != -1) {
                        val clickIntent = Intent(context, HabitWidgetProvider::class.java).apply {
                            action = ACTION_TOGGLE
                            putExtra("EXTRA_HABIT_ID", habitId)
                        }
                        val clickPending = android.app.PendingIntent.getBroadcast(
                            context, habitId, clickIntent,
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(ROW_IDS[i], clickPending)
                        views.setOnClickPendingIntent(TOGGLE_IDS[i], clickPending)
                    }

                } else {
                    views.setViewVisibility(ROW_IDS[i], View.GONE)
                }
            }

            if (total > MAX_ROWS) {
                views.setViewVisibility(R.id.more_row, View.VISIBLE)
                views.setTextViewText(R.id.more_row, "+${total - MAX_ROWS} more")
            } else {
                views.setViewVisibility(R.id.more_row, View.GONE)
            }

            for (id in ids) manager.updateAppWidget(id, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, manager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val habitId = intent.getIntExtra("EXTRA_HABIT_ID", -1)
            if (habitId != -1) {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_DATA, null) ?: return
                
                try {
                    val root = JSONObject(jsonStr)
                    val habits = root.optJSONArray("habits") ?: JSONArray()
                    
                    for (i in 0 until habits.length()) {
                        val habit = habits.getJSONObject(i)
                        if (habit.optInt("id") == habitId) {
                            val current = habit.optBoolean("completed", false)
                            habit.put("completed", !current)
                            break
                        }
                    }
                    
                    root.put("habits", habits)
                    prefs.edit().putString(KEY_DATA, root.toString()).apply()

                    // Queue action
                    val queueStr = prefs.getString("pending_actions", "[]")
                    val queue = JSONArray(queueStr)
                    queue.put(JSONObject().apply {
                        put("type", "habit")
                        put("id", habitId)
                        put("timestamp", System.currentTimeMillis())
                    })
                    prefs.edit().putString("pending_actions", queue.toString()).apply()

                    refreshAll(context)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
