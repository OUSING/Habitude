package com.adi.habitude.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

class DailyProgressWidgetProvider : AppWidgetProvider() {
    companion object {
        const val PREFS_NAME = "HabitWidgetPrefs"
        const val KEY_DONE = "todayDone"
        const val KEY_TOTAL = "todayTotal"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, DailyProgressWidgetProvider::class.java)
            )
            if (ids.isNotEmpty()) render(context, manager, ids)
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val done = prefs.getInt(KEY_DONE, 0).coerceAtLeast(0)
            val total = prefs.getInt(KEY_TOTAL, 0).coerceAtLeast(0)
            val progress = if (total > 0) (done.toFloat() / total * 100f).toInt().coerceIn(0,100) else 0

            val views = RemoteViews(context.packageName, R.layout.widget_daily_progress)
            views.setTextViewText(R.id.progress_value, "$done / $total")
            views.setTextViewText(
                R.id.progress_caption,
                if (total == 0) "No habits scheduled today"
                else if (done >= total) "All habits complete"
                else "$progress% complete"
            )
            views.setProgressBar(R.id.daily_progress, 100, progress, false)

            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (intent != null) {
                val pending = PendingIntent.getActivity(
                    context, 2102, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.progress_widget_root, pending)
            }

            for (id in ids) manager.updateAppWidget(id, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, manager, appWidgetIds)
    }
}
