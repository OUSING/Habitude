package com.adi.habitude.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.view.View
import android.widget.RemoteViews

class StepWidgetProvider : AppWidgetProvider() {
    companion object {
        const val PREFS_NAME = "HabitWidgetPrefs"
        const val KEY_STEPS = "todaySteps"
        const val KEY_STEP_GOAL = "stepGoal"

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, StepWidgetProvider::class.java)
            )
            if (ids.isNotEmpty()) render(context, manager, ids)
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val steps = prefs.getInt(KEY_STEPS, 0).coerceAtLeast(0)
            val goal = prefs.getInt(KEY_STEP_GOAL, 8000).coerceAtLeast(1)
            val progress = (steps.toFloat() / goal.toFloat() * 100f).toInt().coerceIn(0, 100)

            val views = RemoteViews(context.packageName, R.layout.widget_step_tracker)
            views.setTextViewText(R.id.step_value, String.format("%,d", steps))
            views.setTextViewText(R.id.step_goal, "of ${String.format("%,d", goal)} steps")
            views.setProgressBar(R.id.step_progress, 100, progress, false)
            views.setTextViewText(
                R.id.step_percent,
                if (steps >= goal) "Goal reached" else "$progress%"
            )

            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (intent != null) {
                val pending = PendingIntent.getActivity(
                    context, 2101, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.step_widget_root, pending)
            }

            for (id in ids) manager.updateAppWidget(id, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, manager, appWidgetIds)
    }
}
