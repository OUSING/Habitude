# capacitor-step-counter

Local day step count via device pedometer (Android step-counter sensor / iOS CoreMotion), for the Habitude app.

## Install

To use npm

```bash
npm install capacitor-step-counter
````

To use yarn

```bash
yarn add capacitor-step-counter
```

Sync native files

```bash
npx cap sync
```

## API

<docgen-index>

* [`isAvailable()`](#isavailable)
* [`checkPermissions()`](#checkpermissions)
* [`requestPermissions()`](#requestpermissions)
* [`getSteps(...)`](#getsteps)
* [`sync()`](#sync)
* [`addListener('stepsChanged', ...)`](#addlistenerstepschanged-)
* [`removeAllListeners()`](#removealllisteners)
* [Interfaces](#interfaces)
* [Type Aliases](#type-aliases)

</docgen-index>

<docgen-api>
<!--Update the source file JSDoc comments and rerun docgen to update the docs below-->

### isAvailable()

```typescript
isAvailable() => Promise<{ available: boolean; }>
```

Whether this device exposes a step sensor / motion coprocessor at all.

**Returns:** <code>Promise&lt;{ available: boolean; }&gt;</code>

--------------------


### checkPermissions()

```typescript
checkPermissions() => Promise<{ steps: StepsPermissionState; }>
```

**Returns:** <code>Promise&lt;{ steps: <a href="#stepspermissionstate">StepsPermissionState</a>; }&gt;</code>

--------------------


### requestPermissions()

```typescript
requestPermissions() => Promise<{ steps: StepsPermissionState; }>
```

Triggers the OS permission prompt (Android: ACTIVITY_RECOGNITION runtime
permission; iOS: the automatic Motion & Fitness prompt on first query).
On success, this also starts the live `stepsChanged` push updates.

**Returns:** <code>Promise&lt;{ steps: <a href="#stepspermissionstate">StepsPermissionState</a>; }&gt;</code>

--------------------


### getSteps(...)

```typescript
getSteps(options: { date: string; }) => Promise<{ steps: number; }>
```

Step count for one local calendar day.

iOS reads this straight from CoreMotion's on-device history (accurate
for roughly the last 7 days, app open or not).

Android has no OS-level step history without Health Connect, so this
plugin keeps its own running daily tally from the TYPE_STEP_COUNTER
sensor instead, kept in sync automatically by `stepsChanged` (see
below) with `sync()` as a one-shot fallback. A day before the plugin
was first synced, or a day the app was never opened, reports 0 —
that's a hardware/OS limitation, not a bug.

| Param         | Type                           |
| ------------- | ------------------------------ |
| **`options`** | <code>{ date: string; }</code> |

**Returns:** <code>Promise&lt;{ steps: number; }&gt;</code>

--------------------


### sync()

```typescript
sync() => Promise<{ today: number; }>
```

One-shot reconcile — reads the current sensor value and folds any
elapsed time into the stored daily tallies (Android only — no-op but
harmless on iOS/web). Used as a fallback on app launch/resume; once
permission is granted, `stepsChanged` keeps things current without
this needing to be called manually.

**Returns:** <code>Promise&lt;{ today: number; }&gt;</code>

--------------------


### addListener('stepsChanged', ...)

```typescript
addListener(eventName: 'stepsChanged', listenerFunc: (data: { today: number; }) => void) => Promise<PluginListenerHandle>
```

Live push updates: fires with today's freshly-reconciled step count
every time the device's pedometer reports new steps — while permission
is granted this starts automatically (on plugin load if already
granted, otherwise right after `requestPermissions` succeeds), so
steps get logged as they're taken with no relaunch, resume, or manual
sync needed. Never fires on web/no-sensor platforms.

| Param              | Type                                               |
| ------------------ | -------------------------------------------------- |
| **`eventName`**    | <code>'stepsChanged'</code>                        |
| **`listenerFunc`** | <code>(data: { today: number; }) =&gt; void</code> |

**Returns:** <code>Promise&lt;<a href="#pluginlistenerhandle">PluginListenerHandle</a>&gt;</code>

--------------------


### removeAllListeners()

```typescript
removeAllListeners() => Promise<void>
```

--------------------


### Interfaces


#### PluginListenerHandle

| Prop         | Type                                      |
| ------------ | ----------------------------------------- |
| **`remove`** | <code>() =&gt; Promise&lt;void&gt;</code> |


### Type Aliases


#### StepsPermissionState

<code>'granted' | 'denied' | 'prompt' | 'unavailable'</code>

</docgen-api>
