import Foundation
import Capacitor

/**
 * Please read the Capacitor iOS Plugin Development Guide
 * here: https://capacitorjs.com/docs/plugins/ios
 *
 * Requires an NSMotionUsageDescription entry in ios/App/App/Info.plist —
 * see the plugin README.
 */
@objc(StepCounterPlugin)
public class StepCounterPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "StepCounterPlugin"
    public let jsName = "StepCounter"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "isAvailable", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "checkPermissions", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "requestPermissions", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getSteps", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "sync", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stopTracking", returnType: CAPPluginReturnPromise)
    ]
    private let implementation = StepCounter()

    public override func load() {
        // If Motion & Fitness access was already granted in a previous
        // session, start pushing live updates immediately — the JS side
        // doesn't have to relaunch, resume, or manually sync to get them.
        if implementation.authorizationStatus() == "granted" {
            startLiveUpdates()
        }
    }

    /// Wires CoreMotion's push updates straight to a JS-visible event —
    /// every time the pedometer reports new steps, listeners on the JS
    /// side (see stepTracker.ts's `startLiveStepUpdates`) get today's
    /// updated count with no polling, relaunch, or manual sync involved.
    private func startLiveUpdates() {
        implementation.startLiveUpdates { [weak self] today in
            self?.notifyListeners("stepsChanged", data: ["today": today])
        }
    }

    @objc func isAvailable(_ call: CAPPluginCall) {
        call.resolve(["available": implementation.isAvailable()])
    }

    @objc func checkPermissions(_ call: CAPPluginCall) {
        guard implementation.isAvailable() else {
            call.resolve(["steps": "unavailable"])
            return
        }
        call.resolve(["steps": implementation.authorizationStatus()])
    }

    @objc func requestPermissions(_ call: CAPPluginCall) {
        guard implementation.isAvailable() else {
            call.resolve(["steps": "unavailable"])
            return
        }
        implementation.requestAuthorization { [weak self] state in
            if state == "granted" {
                self?.startLiveUpdates()
            }
            call.resolve(["steps": state])
        }
    }

    @objc func getSteps(_ call: CAPPluginCall) {
        guard let date = call.getString("date") else {
            call.reject("Missing required 'date' option (\"YYYY-MM-DD\").")
            return
        }
        implementation.steps(forDate: date) { steps, error in
            if let error = error {
                call.reject("Failed to read step data.", nil, error)
                return
            }
            call.resolve(["steps": steps])
        }
    }

    // iOS has no local ledger to reconcile — CoreMotion already keeps its
    // own history — so `sync` is just an alias for "today's steps".
    @objc func sync(_ call: CAPPluginCall) {
        let today = DateFormatter()
        today.dateFormat = "yyyy-MM-dd"
        let todayStr = today.string(from: Date())
        implementation.steps(forDate: todayStr) { steps, error in
            if let error = error {
                call.reject("Failed to read step data.", nil, error)
                return
            }
            call.resolve(["today": steps])
        }
    }

    // No persistent service to tear down on iOS — CoreMotion's history is
    // read on demand regardless of app state, so this is a harmless no-op
    // kept only so JS can call `stopTracking()` on either platform.
    @objc func stopTracking(_ call: CAPPluginCall) {
        call.resolve()
    }
}
