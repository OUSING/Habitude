import Foundation
import CoreMotion

/**
 * Thin wrapper around CoreMotion's CMPedometer.
 *
 * Unlike Android's raw sensor, CMPedometer keeps its own rolling history
 * (roughly the last 7 days) at the OS level, independent of whether this
 * app was open — so date-range queries are simply accurate, no manual
 * baseline bookkeeping needed here.
 */
@objc public class StepCounter: NSObject {
    private let pedometer = CMPedometer()
    private let calendar = Calendar.current
    private var isUpdating = false

    private func dayFormatter() -> DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = TimeZone.current
        return formatter
    }

    @objc public func isAvailable() -> Bool {
        return CMPedometer.isStepCountingAvailable()
    }

    /// Reads current authorization *without* prompting — CoreMotion has no
    /// separate "check" call, but `authorizationStatus()` (iOS 11+) reports
    /// the current state without side effects.
    @objc public func authorizationStatus() -> String {
        switch CMPedometer.authorizationStatus() {
        case .authorized: return "granted"
        case .denied, .restricted: return "denied"
        case .notDetermined: return "prompt"
        @unknown default: return "prompt"
        }
    }

    @objc public func steps(forDate dateString: String, completion: @escaping (Int, Error?) -> Void) {
        guard CMPedometer.isStepCountingAvailable() else {
            completion(0, nil)
            return
        }
        guard let day = dayFormatter().date(from: dateString) else {
            completion(0, nil)
            return
        }
        let start = calendar.startOfDay(for: day)
        let now = Date()
        let end = calendar.isDateInToday(day)
            ? now
            : (calendar.date(byAdding: .day, value: 1, to: start) ?? now)

        pedometer.queryPedometerData(from: start, to: end) { data, error in
            if let error = error {
                completion(0, error)
                return
            }
            completion(data?.numberOfSteps.intValue ?? 0, nil)
        }
    }

    /// CoreMotion has no explicit "request permission" call — querying data
    /// is itself what triggers the system's Motion & Fitness prompt on
    /// first use, so this just performs a query for today and reports the
    /// resulting authorization state.
    @objc public func requestAuthorization(completion: @escaping (String) -> Void) {
        let today = dayFormatter().string(from: Date())
        steps(forDate: today) { [weak self] _, _ in
            completion(self?.authorizationStatus() ?? "prompt")
        }
    }

    /// Subscribes to CMPedometer's live push updates from the start of
    /// today onward — `onUpdate` fires with the running total every time
    /// the pedometer reports new steps, no polling or app relaunch/resume
    /// needed. This is what makes tracking automatic on iOS.
    @objc public func startLiveUpdates(_ onUpdate: @escaping (Int) -> Void) {
        guard CMPedometer.isStepCountingAvailable(), !isUpdating else { return }
        isUpdating = true
        let start = calendar.startOfDay(for: Date())
        pedometer.startUpdates(from: start) { data, error in
            guard let data = data, error == nil else { return }
            onUpdate(data.numberOfSteps.intValue)
        }
    }

    @objc public func stopLiveUpdates() {
        guard isUpdating else { return }
        pedometer.stopUpdates()
        isUpdating = false
    }
}
