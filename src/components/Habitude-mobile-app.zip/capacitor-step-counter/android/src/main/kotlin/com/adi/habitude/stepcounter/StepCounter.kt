package com.adi.habitude.stepcounter

import android.content.Context
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wraps the device's TYPE_STEP_COUNTER hardware sensor.
 *
 * That sensor only ever reports "steps since last device reboot" — Android
 * has no built-in per-day history without Health Connect (a much heavier
 * integration: separate installed app, its own permission model, a whole
 * records API). So instead this class keeps its own tiny per-day ledger in
 * SharedPreferences:
 *
 *  - `last_sensor_total` / `baseline_date`: the last cumulative sensor value
 *    reconciled for the current day.
 *  - `today_accumulated`: today's step count as of the last reconcile —
 *    kept so a sensor reset (see below) doesn't lose what was already
 *    counted.
 *  - `day_YYYY-MM-DD`: the finalized step count for a past day, written
 *    once we notice the calendar date has rolled over since the baseline.
 *
 * Two things feed the ledger: an explicit one-shot [sync] (JS calls this on
 * app launch/resume as a fallback), and [startLiveUpdates], which keeps a
 * standing registration on the sensor so today's count updates the moment
 * new steps are taken — no relaunch, resume, or manual sync required.
 */
class StepCounter(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("capacitor_step_counter", Context.MODE_PRIVATE)

    private val sensorManager: SensorManager? =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun todayStr(): String = dayFormat.format(Date())

    fun hasSensor(): Boolean =
        sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null

    /** Reads the sensor's current cumulative value once. The step-counter
     *  sensor delivers its value immediately on registration (it's a
     *  continuously-updated hardware counter, not an event stream you have
     *  to wait on), so a short timeout is just a safety net. */
    fun readCurrentTotal(onResult: (Float?) -> Unit) {
        val manager = sensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (manager == null || sensor == null) {
            onResult(null)
            return
        }

        var resolved = false
        val handler = Handler(Looper.getMainLooper())
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (resolved) return
                resolved = true
                manager.unregisterListener(this)
                onResult(event.values.firstOrNull())
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        try {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        } catch (security: SecurityException) {
            if (!resolved) {
                resolved = true
                onResult(null)
            }
            return
        }

        // Safety net: some devices/emulators never deliver a value.
        handler.postDelayed({
            if (!resolved) {
                resolved = true
                manager.unregisterListener(listener)
                onResult(null)
            }
        }, 4000)
    }

    /** Reconciles a raw cumulative sensor reading against the stored
     *  baseline, persists the updated ledger, and returns today's step
     *  count. Shared by the one-shot [sync] call and the continuous live
     *  listener in [startLiveUpdates] — this is the only place that touches
     *  the ledger, so both paths stay consistent.
     *
     *  TYPE_STEP_COUNTER reports steps *since the device last rebooted*,
     *  so a reboot (nightly restart, OS update, dead battery...) resets the
     *  sensor's cumulative value back down. When that happens `total` can
     *  come back lower than the stored `baseline_total`, which would make
     *  `total - baselineTotal` go negative. We bank whatever was already
     *  accumulated today (`today_accumulated`) and re-baseline against the
     *  post-reboot value, instead of losing today's count / getting stuck
     *  reporting 0 for the rest of the day. */
    /**
     * Reconciles one raw TYPE_STEP_COUNTER reading.
     *
     * IMPORTANT: this uses the PREVIOUS SENSOR READING, not
     * `today + (total - baseline)` on every call. The latter is very easy to
     * double-count when a live sensor callback and a foreground sync happen
     * close together. A single lock also makes concurrent callbacks safe.
     */
    @Synchronized
    private fun reconcile(total: Float): Int {
        val today = todayStr()
        val storedDate = prefs.getString("baseline_date", null)
        val lastTotal = prefs.getFloat("last_sensor_total", -1f)
        val todaySteps = prefs.getInt("today_accumulated", 0)
        val lastEventMs = prefs.getLong("last_event_elapsed_ms", -1L)
        val editor = prefs.edit()

        // Version 2 deliberately discards the old ledger once. Earlier
        // versions could already contain inflated values from the broken
        // sync path, so carrying that value forward would preserve the bug.
        val schema = prefs.getInt("ledger_schema", 0)
        if (schema != 2) {
            editor.clear()
            editor.putInt("ledger_schema", 2)
            editor.putString("baseline_date", today)
            editor.putFloat("last_sensor_total", total)
            editor.putLong("last_event_elapsed_ms", SystemClock.elapsedRealtime())
            editor.putInt("today_accumulated", 0)
            editor.commit()
            return 0
        }

        if (storedDate == null || lastTotal < 0f) {
            // Migrate away from the old baseline-based implementation. Its
            // accumulated value may already contain double-counted steps, so
            // deliberately start a clean ledger at the first reading seen by
            // this version. Future readings are delta-based and serialized.
            editor.remove("baseline_total")
            editor.putString("baseline_date", today)
            editor.putFloat("last_sensor_total", total)
            editor.putInt("today_accumulated", 0)
            editor.putLong("last_event_elapsed_ms", SystemClock.elapsedRealtime())
            editor.commit()
            return 0
        }

        if (storedDate != today) {
            // Attribute steps taken since the last reading to the day that
            // was being tracked. Then start today from the current sensor
            // value so yesterday's steps can never leak into today.
            val delta = if (total >= lastTotal) (total - lastTotal).toInt() else 0
            val finalized = todaySteps + delta
            editor.putInt("day_$storedDate", finalized)
            editor.putString("baseline_date", today)
            editor.putFloat("last_sensor_total", total)
            editor.putLong("last_event_elapsed_ms", SystemClock.elapsedRealtime())
            editor.putInt("today_accumulated", 0)
            editor.commit()
            return 0
        }

        // TYPE_STEP_COUNTER resets after reboot. Never subtract a reset
        // value, and never add the same sensor value twice.
        if (total < lastTotal) {
            editor.putFloat("last_sensor_total", total)
            editor.putLong("last_event_elapsed_ms", SystemClock.elapsedRealtime())
            editor.commit()
            return todaySteps
        }

        val nowMs = SystemClock.elapsedRealtime()
        val delta = (total - lastTotal).toInt().coerceAtLeast(0)

        // A TYPE_STEP_COUNTER reading is cumulative. A jump of hundreds of
        // steps in a couple of seconds is not physically plausible and is
        // characteristic of the duplicate/batched readings that caused the
        // old sync bug. Re-baseline such a jump instead of poisoning today's
        // total. When the app was backgrounded, the elapsed time is large and
        // the corresponding legitimate batch is accepted.
        if (delta > 0 && lastEventMs > 0L) {
            val elapsedSeconds = ((nowMs - lastEventMs).coerceAtLeast(1L)) / 1000.0
            val allowed = kotlin.math.ceil(elapsedSeconds * 5.0 + 20.0).toInt()
            if (delta > allowed) {
                editor.putFloat("last_sensor_total", total)
                editor.putLong("last_event_elapsed_ms", nowMs)
                editor.commit()
                return todaySteps
            }
        }

        val updated = todaySteps + delta
        editor.putFloat("last_sensor_total", total)
        editor.putLong("last_event_elapsed_ms", nowMs)
        editor.putInt("today_accumulated", updated)
        editor.commit()
        return updated
    }

    /**
     * Returns the already-recorded total without reading the hardware sensor.
     *
     * IMPORTANT: this method is intentionally READ-ONLY. The hardware sensor
     * is reconciled only by the single live listener. A manual/UI "sync" must
     * never be able to add steps, because that creates a second ingestion path
     * and can double-count on devices that batch sensor events.
     */
    fun sync(onResult: (todaySteps: Int) -> Unit) {
        onResult(prefs.getInt("today_accumulated", 0))
    }

    /** Steps for any local calendar date. Today is the already-recorded ledger
     * value; the live sensor listener is responsible for advancing it. */
    fun getSteps(date: String, onResult: (Int) -> Unit) {
        onResult(if (date == todayStr()) prefs.getInt("today_accumulated", 0) else prefs.getInt("day_$date", 0))
    }

    private var liveListener: SensorEventListener? = null

    /** Keeps a standing registration on the step sensor so [onChange] fires
     *  with a freshly-reconciled "today" total every time the hardware
     *  reports new steps — this is what makes tracking automatic instead of
     *  needing the app relaunched, resumed, or a manual sync button. The
     *  step-counter sensor is a low-power batched sensor, so holding a
     *  registration open is cheap. Safe to call repeatedly; only one
     *  registration is kept until [stopLiveUpdates] is called. */
    fun startLiveUpdates(onChange: (Int) -> Unit) {
        if (liveListener != null) return
        val manager = sensorManager
        val sensor = manager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val total = event.values.firstOrNull() ?: return
                onChange(reconcile(total))
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        try {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
            liveListener = listener
        } catch (_: SecurityException) {
            // Permission can be revoked while the app is alive. Leave the
            // listener unset so a later permission grant/resume can retry.
            liveListener = null
        }
    }

    fun stopLiveUpdates() {
        val listener = liveListener ?: return
        sensorManager?.unregisterListener(listener)
        liveListener = null
    }
}
