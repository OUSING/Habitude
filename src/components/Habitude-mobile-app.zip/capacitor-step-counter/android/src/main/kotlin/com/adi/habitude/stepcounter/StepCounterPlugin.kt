package com.adi.habitude.stepcounter

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionState
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission

/**
 * ACTIVITY_RECOGNITION is only a real runtime permission from Android 10
 * (API 29) onward — on older versions the step-counter sensor is usable
 * with no prompt at all, so this plugin treats it as pre-granted there.
 *
 * The actual sensor listener now lives in [StepForegroundService], not
 * here, so tracking survives the app being backgrounded or closed outright.
 * This plugin starts/stops that service and, while it's alive itself, just
 * relays the service's updates on to JS for the live on-screen counter.
 */
@CapacitorPlugin(
    name = "StepCounter",
    permissions = [
        Permission(strings = [Manifest.permission.ACTIVITY_RECOGNITION], alias = "steps")
    ]
)
class StepCounterPlugin : Plugin() {

    private lateinit var implementation: StepCounter

    override fun load() {
        implementation = StepCounter(context)
        // Relay the foreground service's updates to JS while this plugin
        // instance (i.e. the app) is alive.
        StepForegroundService.uiListener = { today ->
            val ret = JSObject()
            ret.put("today", today)
            notifyListeners("stepsChanged", ret)
        }
        // If permission was already granted in a previous session, (re)start
        // the tracking service immediately — the JS side doesn't have to do
        // anything (relaunch, resume, manual sync) to get updates flowing,
        // and this keeps running after the app is backgrounded or closed.
        if (currentPermissionLabel() == "granted") {
            startTrackingService()
        }
    }

    override fun handleOnDestroy() {
        // Only detach the UI relay — the foreground service (and the sensor
        // listener it owns) deliberately keeps running so steps taken while
        // the app is closed still get counted.
        if (StepForegroundService.uiListener != null) {
            StepForegroundService.uiListener = null
        }
    }

    private fun startTrackingService() {
        val intent = Intent(context, StepForegroundService::class.java)
        ContextCompat.startForegroundService(context, intent)
    }

    private fun stopTrackingService() {
        context.stopService(Intent(context, StepForegroundService::class.java))
    }

    private fun needsRuntimePermission(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    private fun currentPermissionLabel(): String {
        if (!needsRuntimePermission()) return "granted"
        return when (getPermissionState("steps")) {
            PermissionState.GRANTED -> "granted"
            PermissionState.DENIED -> "denied"
            else -> "prompt"
        }
    }

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        val ret = JSObject()
        ret.put("available", implementation.hasSensor())
        call.resolve(ret)
    }

    @PluginMethod
    override fun checkPermissions(call: PluginCall) {
        if (!implementation.hasSensor()) {
            val ret = JSObject()
            ret.put("steps", "unavailable")
            call.resolve(ret)
            return
        }
        val ret = JSObject()
        ret.put("steps", currentPermissionLabel())
        call.resolve(ret)
    }

    @PluginMethod
    override fun requestPermissions(call: PluginCall) {
        if (!implementation.hasSensor()) {
            val ret = JSObject()
            ret.put("steps", "unavailable")
            call.resolve(ret)
            return
        }
        if (!needsRuntimePermission() || currentPermissionLabel() == "granted") {
            startTrackingService()
            val ret = JSObject()
            ret.put("steps", "granted")
            call.resolve(ret)
            return
        }
        // Safely invoke Capacitor's native permission request logic
        requestPermissionForAlias("steps", call, "permissionCallback")
    }

    @com.getcapacitor.annotation.PermissionCallback
    private fun permissionCallback(call: PluginCall) {
        val state = currentPermissionLabel()
        if (state == "granted") {
            startTrackingService()
        }
        val ret = JSObject()
        ret.put("steps", state)
        call.resolve(ret)
    }

    @PluginMethod
    fun getSteps(call: PluginCall) {
        val date = call.getString("date")
        if (date.isNullOrBlank()) {
            call.reject("Missing required 'date' option (\"YYYY-MM-DD\").")
            return
        }
        implementation.getSteps(date) { steps ->
            val ret = JSObject()
            ret.put("steps", steps)
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun sync(call: PluginCall) {
        implementation.sync { today ->
            val ret = JSObject()
            ret.put("today", today)
            call.resolve(ret)
        }
    }

    /** Explicitly stops background tracking (the foreground service and its
     *  notification) — called when the user turns the in-app toggle off.
     *  Without this, tracking would otherwise persist across app restarts
     *  by design, per [load]. */
    @PluginMethod
    fun stopTracking(call: PluginCall) {
        stopTrackingService()
        call.resolve()
    }
}
