package com.adi.habitude.stepcounter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Keeps the TYPE_STEP_COUNTER sensor listener alive independent of the
 * app's Activity/WebView lifecycle.
 *
 * Why this exists: [StepCounterPlugin] previously registered the sensor
 * listener itself and tore it down in `handleOnDestroy()`, which fires the
 * moment the app's Activity is destroyed (backgrounded long enough to be
 * reclaimed, or closed/swiped away outright). That meant steps taken while
 * the app wasn't in the foreground were simply never recorded. A foreground
 * service is the supported way to keep small background work like a sensor
 * listener running after the Activity is gone — Android just requires a
 * persistent, low-priority notification while it's active so the user knows
 * something is running.
 *
 * The service owns the sensor registration and writes to the same
 * SharedPreferences ledger [StepCounter] always has; [StepCounterPlugin]
 * only attaches [uiListener] while the app is actually open, purely to
 * forward live counts to JS for the on-screen counter. Nothing here is lost
 * or reset when that listener detaches — the ledger (and this service) keep
 * running.
 */
class StepForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "step_tracking"
        private const val NOTIFICATION_ID = 4291

        /** Set by the plugin while the app is in the foreground so the UI
         *  gets instant push updates. Left null the rest of the time — the
         *  ledger in SharedPreferences keeps updating either way. */
        @Volatile
        var uiListener: ((Int) -> Unit)? = null
    }

    private lateinit var stepCounter: StepCounter

    override fun onCreate() {
        super.onCreate()
        stepCounter = StepCounter(applicationContext)

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // No-op if a listener is already registered (e.g. this service was
        // already running and the app just relaunched onto it).
        stepCounter.startLiveUpdates { today -> uiListener?.invoke(today) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: if the OS kills this process under memory pressure,
        // it will attempt to recreate the service (with a null intent),
        // which re-registers the sensor listener in onCreate().
        return START_STICKY
    }

    override fun onDestroy() {
        stepCounter.stopLiveUpdates()
        uiListener = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager?.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Step tracking",
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    description = "Keeps counting your steps in the background"
                    setShowBadge(false)
                }
                manager?.createNotificationChannel(channel)
            }
        }

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = launchIntent?.let {
            PendingIntent.getActivity(
                this,
                0,
                it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Tracking your steps")
            .setContentText("Counting steps in the background")
            .setSmallIcon(applicationInfo.icon)
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .build()
    }
}
