import { WebPlugin } from '@capacitor/core';

import type { StepCounterPlugin, StepsPermissionState } from './definitions';

/** No pedometer in a browser — every call resolves to a harmless "nothing
 *  available" answer so the rest of the app never has to branch on platform. */
export class StepCounterWeb extends WebPlugin implements StepCounterPlugin {
  async isAvailable(): Promise<{ available: boolean }> {
    return { available: false };
  }

  async checkPermissions(): Promise<{ steps: StepsPermissionState }> {
    return { steps: 'unavailable' };
  }

  async requestPermissions(): Promise<{ steps: StepsPermissionState }> {
    return { steps: 'unavailable' };
  }

  async getSteps(): Promise<{ steps: number }> {
    return { steps: 0 };
  }

  async sync(): Promise<{ today: number }> {
    return { today: 0 };
  }

  async stopTracking(): Promise<void> {
    return;
  }
}
