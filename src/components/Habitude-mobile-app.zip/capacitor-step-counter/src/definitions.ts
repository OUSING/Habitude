import type { PluginListenerHandle } from '@capacitor/core';

export type StepsPermissionState = 'granted' | 'denied' | 'prompt' | 'unavailable';

export interface StepCounterPlugin {
  /** Whether this device exposes a step sensor / motion coprocessor at all. */
  isAvailable(): Promise<{ available: boolean }>;

  checkPermissions(): Promise<{ steps: StepsPermissionState }>;

  /** Triggers the OS permission prompt (Android: ACTIVITY_RECOGNITION runtime
   *  permission; iOS: the automatic Motion & Fitness prompt on first query).
   *  On success, this also starts the live `stepsChanged` push updates. */
  requestPermissions(): Promise<{ steps: StepsPermissionState }>;

  /**
   * Step count for one local calendar day.
   *
   * iOS reads this straight from CoreMotion's on-device history (accurate
   * for roughly the last 7 days, app open or not).
   *
   * Android has no OS-level step history without Health Connect, so this
   * plugin keeps its own running daily tally from the TYPE_STEP_COUNTER
   * sensor instead, kept in sync automatically by `stepsChanged` (see
   * below) with `sync()` as a one-shot fallback. A day before the plugin
   * was first synced, or a day the app was never opened, reports 0 —
   * that's a hardware/OS limitation, not a bug.
   */
  getSteps(options: { date: string }): Promise<{ steps: number }>;

  /** One-shot reconcile — reads the current sensor value and folds any
   *  elapsed time into the stored daily tallies (Android only — no-op but
   *  harmless on iOS/web). Used as a fallback on app launch/resume; once
   *  permission is granted, `stepsChanged` keeps things current without
   *  this needing to be called manually. */
  sync(): Promise<{ today: number }>;

  /**
   * Stops background tracking. On Android this tears down the foreground
   * service (and its notification) that keeps counting steps while the app
   * is backgrounded or closed — call this when the user explicitly turns
   * tracking off, otherwise it keeps running across app restarts by design.
   * No-op on iOS/web, where there's no persistent service to stop.
   */
  stopTracking(): Promise<void>;

  /**
   * Live push updates: fires with today's freshly-reconciled step count
   * every time the device's pedometer reports new steps — while permission
   * is granted this starts automatically (on plugin load if already
   * granted, otherwise right after `requestPermissions` succeeds), so
   * steps get logged as they're taken with no relaunch, resume, or manual
   * sync needed. Never fires on web/no-sensor platforms.
   */
  addListener(
    eventName: 'stepsChanged',
    listenerFunc: (data: { today: number }) => void
  ): Promise<PluginListenerHandle>;

  removeAllListeners(): Promise<void>;
}
