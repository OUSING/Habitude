// Native build: re-export the real Capacitor plugin (local package at
// ../../capacitor-step-counter). The web build has its own no-op stub of
// this same file so the app compiles without the native plugin installed.
export { StepCounter, type StepsPermissionState } from "capacitor-step-counter";
